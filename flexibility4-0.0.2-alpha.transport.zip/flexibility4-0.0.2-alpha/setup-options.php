<?php

/**
 * Script to interact with user during Flexibility package install
 *
 * Copyright 2011 Menno Pietersen <info@designfromwithin.com>
 * @author Menno Pietersen <info@designfromwithin.com>
 * 13/12/2011
 *
 *  is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public License as published by the Free
 * Software Foundation; either version 2 of the License, or (at your option) any
 * later version.
 *
 *  is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * ; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package flexibility
 */
/**
 * Flexibility is a fully functional MODX Revolution website. Quickstart projects by creating a fully working MODX Revolution website with just one package.: Script to interact with user during Flexibility package install
 * @package flexibility
 * @subpackage build
 */
/* Use these if you would like to do different things depending on what's happening */

/* The return value from this script should be an HTML form (minus the
 * <form> tags and submit button) in a single string.
 *
 * The form will be shown to the user during install
 * after the readme.txt display.
 *
 * This example presents an HTML form to the user with one input field
 * (you can have more).
 *
 * The user's entries in the form's input field(s) will be available
 * in any php resolvers with $modx->getOption('field_name', $options, 'default_value').
 *
 * You can use the value(s) to set system settings, snippet properties,
 * chunk content, etc. One common use is to use a checkbox and ask the
 * user if they would like to install an example resource for your
 * component.
 */

$output = '
<h2>Thank you for installing Flexibility 4!</h2>
<p>This package is meant to be used once to quick-start MODX website projects. It will install a lot of things and provide a nice responsive MODX website based on the Foundation 4 framework from ZURB.</p>
<p>You will be able to update this package (and the individual sub-packages like "Wayfinder") without losing any content or TV settings.</p>
<p><strong>Please do not change any files that start with "flex-4", these will be overwritten when you update the Flexibility 4 template!</strong></p>
<h4>Homepage</h4>
<p>After installing this package, you will need to change the template of your homepage to: <b>flex-4 Homepage</b>.</p>
<h4>Image gallery</h4>
<p>The image gallery settings can be found in the main menu under: "Components" > "Gallery".<br>
To creat a gallery page simply create a new resource and select the <b>flex-4 Gallery</b> as the template</p>
<h4>Blog (articles)</h4>
<p>To use the blog/articles feature, right-click on the "Resources" tree where you want to create a blog and select: "Create" > "Create Articles here".<br>
Once you have clicked on your new blog/articles resource, please make sure that you select the following templates under the template tab:</p>
<ul>
	<li>Uses Template: <b>flex-4 Articles container</b></li>
	<li>Article Template: <b>flex-4 Articles post</b></li>
	<li>Article Row Chunk: <b>flex-4-articleRowTpl</b></li>
</ul>
';


return $output;