<?php
/**
 * Flexibility 4
 *
 * @package flexibility4
 * @language en
 */
$_lang['flex-4.view_gallery'] = 'View gallery';
$_lang['flex-4.posted_on'] = 'Posted on';
$_lang['flex-4.back'] = 'Back';
$_lang['flex-4.comments'] = 'Comments';
$_lang['flex-4.add_a_comment'] = 'Add a comment';
$_lang['flex-4.latest_posts'] = 'Latest posts';
$_lang['flex-4.latest_comments'] = 'Latest comments';
$_lang['flex-4.archives'] = 'Archives';
$_lang['flex-4.tags'] = 'Tags';
$_lang['flex-4.posted_by'] = 'Posted by';
$_lang['flex-4.read_more'] = 'Read more';