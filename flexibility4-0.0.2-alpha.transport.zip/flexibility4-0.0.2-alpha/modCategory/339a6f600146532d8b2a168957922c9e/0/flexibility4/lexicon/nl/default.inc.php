<?php
/**
 * Flexibility 4
 *
 * @package flexibility4
 * @language nl
 */
$_lang['flex-4.view_gallery'] = 'Bekijk gallerij';
$_lang['flex-4.posted_on'] = 'Geplaatst op';
$_lang['flex-4.back'] = 'Terug';
$_lang['flex-4.comments'] = 'Reacties';
$_lang['flex-4.add_a_comment'] = 'Voeg een reactie toe';
$_lang['flex-4.latest_posts'] = 'Nieuwste artikelen';
$_lang['flex-4.latest_comments'] = 'Nieuwste reacties';
$_lang['flex-4.archives'] = 'Archief';
$_lang['flex-4.tags'] = 'Tags';
$_lang['flex-4.posted_by'] = 'Geplaatst door';
$_lang['flex-4.read_more'] = 'Lees meer';
