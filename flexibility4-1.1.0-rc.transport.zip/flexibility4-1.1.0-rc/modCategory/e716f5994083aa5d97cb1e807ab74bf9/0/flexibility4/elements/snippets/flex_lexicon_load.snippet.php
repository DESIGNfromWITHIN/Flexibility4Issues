<?php
$modx->lexicon->load('flexibility4:default');