<?php
/**
 * en default topic lexicon file for flexibility4 extra
 *
 * Copyright 2013 by Menno Pietersen info@flexibilitymodx.com
 * Created on 09-15-2013
 *
 * flexibility4 is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * flexibility4 is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * flexibility4; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package flexibility4
 */

/**
 * Description
 * -----------
 * en default topic lexicon strings
 *
 * Variables
 * ---------
 * @var $modx modX
 * @var $scriptProperties array
 *
 * @package flexibility4
 **/



/* Used in flex_ArticleRowTpl.html */
$_lang['articles.posted_by'] = 'Posted by';
$_lang['articles.read_more'] = 'Read more';
$_lang['articles.comments'] = 'Comments';

/* Used in flex_GalleryAlbumTpl.chunk.html */
$_lang['To the gallery overview'] = 'To the gallery overview';

/* Used in search_results_-_flexibility_4.template.html */
$_lang['Search results'] = '';

/* Used in flex-article.template.html */
$_lang['flexibility4.backtonews'] = 'Back to the news overview';
$_lang['Laatste reacties'] = 'Latest comments';
$_lang['Tags'] = 'Tags';
$_lang['Archief'] = 'Archive';

/* Used in transport.settings.php */
$_lang['setting_flex_footer_text'] = 'Footer text - Flexibility 4';
$_lang['setting_flex_footer_text_desc'] = 'The text on the center of the footer';
$_lang['setting_flex_site_logo_url'] = 'Site logo URL - Flexibility 4';
$_lang['setting_flex_site_logo_url_desc'] = 'Link for the header logo';
$_lang['setting_flex_site_logo_link_title'] = 'Logo alt text - Flexibility 4';
$_lang['setting_flex_site_logo_link_title_desc'] = 'The alt text for the header logo';
$_lang['setting_flex_main_navigation_type'] = 'Use Foundation top bar for main navigation - Flexibility 4';
$_lang['setting_flex_main_navigation_type_desc'] = 'If you want to use the Foundation top bar, enter \'Yes\'.
For default Wayfinder call enter \'No\'.';
$_lang['setting_flex_header_logo'] = 'Header logo - Flexibility 4';
$_lang['setting_flex_header_logo_desc'] = 'Path to the logo you want in the header';
$_lang['setting_flex_search_results_page_id'] = 'Search results page ID - Flexibility 4';
$_lang['setting_flex_search_results_page_id_desc'] = 'The ID of the search results page (you need to create it)';