flexibility4


Author
Menno Pietersen <http://flexibilitymodx.com>
Copyright 2013

Official Documentation
https://github.com/DESIGNfromWITHIN/Flexibility4Issues

Bugs, questions and feature requests
https://github.com:DESIGNfromWITHIN/Flexibility4Issues

Created using
- MODX Revolution 2.2.8-pl (traditional)
- MyComponent 3.1.1-pl by Bob Ray
- Foundation 4 Framework by ZURB
- SASS
- GitHub
- Compass