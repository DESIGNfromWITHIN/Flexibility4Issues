<?php
/**
 * nl default topic lexicon file for flexibility4 extra
 *
 * Copyright 2013 by Menno Pietersen info@flexibilitymodx.com
 * Created on 09-20-2013
 *
 * flexibility4 is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * flexibility4 is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * flexibility4; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package flexibility4
 */

/**
 * Description
 * -----------
 * nl default topic lexicon strings
 *
 * Variables
 * ---------
 * @var $modx modX
 * @var $scriptProperties array
 *
 * @package flexibility4
 **/

/* Used in flex_ArticleRowTpl.chunk.html */
$_lang['articles.posted_by'] = 'Geplaatst door';
$_lang['articles.comments'] = 'Reacties';
$_lang['articles.read_more'] = 'Lees meer';

/* Used in flex_GalleryAlbumTpl.chunk.html */
$_lang['To the gallery overview'] = 'Naar het overzicht';

/* Used in flex_contact_form.chunk.html */
$_lang['Contact Form'] = 'Contact formulier';
$_lang['Name'] = 'Naam';
$_lang['Email'] = 'Email';
$_lang['Subject'] = 'Onderwerp';
$_lang['Message'] = 'Bericht';
$_lang['Send Contact Inquiry'] = 'Verstuur';

/* Used in search_results_-_flexibility_4.template.html */
$_lang['Search results'] = 'Zoek resultaten';

/* Used in flex-article.template.html */
$_lang['flexibility4.backtonews'] = 'Terug naar het nieuws overzicht';
$_lang['flexibility4.latest_comments'] = 'Laatste reacties';
$_lang['flexibility4.tags'] = 'Tags';
$_lang['flexibility4.archive'] = 'Archief';
$_lang['flexibility4.latest_posts'] = 'Laarte artikelen';

/* Used in transport.settings.php */
$_lang['setting_flex_footer_text'] = 'Footer tekst';
$_lang['setting_flex_footer_text_desc'] = 'De tekst in de footer';
$_lang['setting_flex_site_logo_url'] = 'Site logo URL';
$_lang['setting_flex_site_logo_url_desc'] = 'Link voor het header logo';
$_lang['setting_flex_site_logo_link_title'] = 'Logo alt tekst';
$_lang['setting_flex_site_logo_link_title_desc'] = 'De alt tekst voor het header logo';
$_lang['setting_flex_main_navigation_type'] = 'Gebruik Foundation top bar als hoofd navigatie';
$_lang['setting_flex_main_navigation_type_desc'] = 'Wilt u de Foundation top bar, kies dan \'Yes\'.
voor een standaard Wayfinder menu kies \'No\'.';
$_lang['setting_flex_header_logo'] = 'Header logo';
$_lang['setting_flex_header_logo_desc'] = 'Pad naar de logo afbeelding in de header';
$_lang['setting_flex_search_results_page_id'] = 'Zoek resultaten pagina ID';
$_lang['setting_flex_search_results_page_id_desc'] = 'Vul het ID nummer van de zoekresultaten pagina. Maak een pagina en selecteer het Search Results template';
$_lang['setting_flex_contact_email'] = 'Email adres voor het contact formulier';
$_lang['setting_flex_contact_email_desc'] = 'Het email adres waar berichten van het contact formulier heen gaan';
$_lang['setting_flex_thank_you_page'] = 'Bedankt pagina ID';
$_lang['setting_flex_thank_you_page_desc'] = 'Vul het ID nummer in van de bedankt pagina. Bezoekers worden hier heen getsuurd na gebruik van het contact formulier.';