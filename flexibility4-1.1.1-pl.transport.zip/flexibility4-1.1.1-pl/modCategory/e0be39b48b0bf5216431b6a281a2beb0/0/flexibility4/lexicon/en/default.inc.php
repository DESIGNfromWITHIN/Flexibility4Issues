<?php
/**
 * en default topic lexicon file for flexibility4 extra
 *
 * Copyright 2013 by Menno Pietersen info@flexibilitymodx.com
 * Created on 09-20-2013
 *
 * flexibility4 is free software; you can redistribute it and/or modify it under the
 * terms of the GNU General Public License as published by the Free Software
 * Foundation; either version 2 of the License, or (at your option) any later
 * version.
 *
 * flexibility4 is distributed in the hope that it will be useful, but WITHOUT ANY
 * WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR
 * A PARTICULAR PURPOSE. See the GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along with
 * flexibility4; if not, write to the Free Software Foundation, Inc., 59 Temple
 * Place, Suite 330, Boston, MA 02111-1307 USA
 *
 * @package flexibility4
 */

/**
 * Description
 * -----------
 * en default topic lexicon strings
 *
 * Variables
 * ---------
 * @var $modx modX
 * @var $scriptProperties array
 *
 * @package flexibility4
 **/



/* Used in flex_ArticleRowTpl.chunk.html */
$_lang['articles.posted_by'] = 'Posted by';
$_lang['articles.comments'] = 'Comments';
$_lang['articles.read_more'] = 'Read more';

/* Used in flex_GalleryAlbumTpl.chunk.html */
$_lang['To the gallery overview'] = 'To the gallery overview';

/* Used in flex_contact_form.chunk.html */
$_lang['Please review the following errors'] = '';
$_lang['Name is a required field'] = '';
$_lang['Email is a required field'] = '';
$_lang['Comment is a required field'] = '';
$_lang['Contact Form'] = 'Contact form';
$_lang['Name'] = 'Name';
$_lang['Email'] = 'Email';
$_lang['Subject'] = 'Subject';
$_lang['Message'] = 'Message';
$_lang['Send Contact Inquiry'] = 'Send';

/* Used in search_results_-_flexibility_4.template.html */
$_lang['Search results'] = 'Search results';

/* Used in flex-article.template.html */
$_lang['flexibility4.backtonews'] = 'Back to news overview';
$_lang['flexibility4.latest_comments'] = 'Latest comments';
$_lang['flexibility4.tags'] = 'Tags';
$_lang['flexibility4.archive'] = 'Archive';
$_lang['flexibility4.latest_posts'] = 'Latest posts';

/* Used in transport.settings.php */
$_lang['setting_flex_footer_text'] = 'Footer text';
$_lang['setting_flex_footer_text_desc'] = 'The text on the center of the footer';
$_lang['setting_flex_site_logo_url'] = 'Site logo URL';
$_lang['setting_flex_site_logo_url_desc'] = 'Link for the header logo';
$_lang['setting_flex_site_logo_link_title'] = 'Logo alt text';
$_lang['setting_flex_site_logo_link_title_desc'] = 'The alt text for the header logo';
$_lang['setting_flex_main_navigation_type'] = 'Use Foundation top bar for main navigation';
$_lang['setting_flex_main_navigation_type_desc'] = 'If you want to use the Foundation top bar, enter \'Yes\'.
For default Wayfinder call enter \'No\'.';
$_lang['setting_flex_header_logo'] = 'Header logo';
$_lang['setting_flex_header_logo_desc'] = 'Path to the logo you want in the header';
$_lang['setting_flex_search_results_page_id'] = 'Search results page ID';
$_lang['setting_flex_search_results_page_id_desc'] = 'Enter the ID number for the search results page. Create a page and select the Search Results template';
$_lang['setting_flex_contact_email'] = 'Email adress for contact form';
$_lang['setting_flex_contact_email_desc'] = 'Enter the email adress to send messages from the contact form to.';
$_lang['setting_flex_thank_you_page'] = 'Thank you page ID';
$_lang['setting_flex_thank_you_page_desc'] = 'Enter the ID number of the thank you page. Visitors will get redirected here after using the contact form.';